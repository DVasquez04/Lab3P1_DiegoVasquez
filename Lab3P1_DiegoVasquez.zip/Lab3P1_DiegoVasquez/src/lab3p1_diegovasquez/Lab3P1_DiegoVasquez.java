/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab3p1_diegovasquez;
import java.util.Scanner;
/**
 *
 * @author Diego Vasquez
 */
public class Lab3P1_DiegoVasquez {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner lea = new Scanner(System.in);
        boolean seguir = true;
        while (seguir){
            System.out.println("1.Euclidiana");
            System.out.println("2.Pokebola");
            System.out.println("3.¡OK Boomer!");
            System.out.println("4.Salir");
            int opcion = lea.nextInt();
            switch(opcion){
                case 1:{
                    System.out.println("Ingrese un limite: ");
                    int lim = lea.nextInt();
                    while (lim < 0){
                        System.out.println("Su limite no puede ser menor a 0... Intentalo de nuevo :D");
                        lim = lea.nextInt();
                    }
                    double suma = 0;
                    for (int I = 1; I <= lim; I++){
                        System.out.println("Ingrese el valor de X");
                        double X = lea.nextInt();
                        System.out.println("Ingrese el valor de Y");
                        double Y = lea.nextInt();
                        
                        double parentesis =X - Y;
                        double ParenSqrd = Math.pow(parentesis,2);
                        suma = suma + ParenSqrd;
                        }
                    double Sqrt = Math.sqrt(suma);
                    System.out.println("La distancia euclidiana es: "+ Sqrt);
                    
                }//fin case 1
                break;
                case 2: {
                    System.out.println("Ingrese un numero:");
                    int N = lea.nextInt();
                    while (N <= 0){
                        System.out.println("El numero no puede ser menor que 0, intentelo de nuevo:");
                        N = lea.nextInt();
                    }
                    //i = filas
                    //j = columnas
                    for (int i = 1; i <= N;i++){
                        for( int j = 1; j<= N*2-1;j++){
                           if(i == 1 || i == N || j == 1 || j == N * 2 - 1 || i < N/2 || (i == N/2-1 && j <= (N/2-1)/3)){
                               System.out.print("*");
                           }else if(i > N/2 + 2 ){
                               System.out.print(" ");
                           }else if(i == N/2+1 && j <= (N*2-1)/3 || i == N/2 && j> (N/2-1)/3 && j > (N/2-1)/3 || i == N/2+2 && j> (N/2-1)/3 || i == N/2+1 && j > (N*2-1)/3 *2){
                               System.out.print("#");
                           }else{
                               System.out.print(" ");
                           }
                        }// fin for interno
                        System.out.println("");
                    }//fin for externo
                }// fin case 2
                break;
                case 3:{
                    System.out.println("Ingrese su año de nacimiento: ");
                    int año = lea.nextInt();
                    if(año >= 2013 && año <= 2025){
                        System.out.println("¡Felicidades usted es de la Gen Alpha!");
                    }else if(año >= 1990 && año <= 2012){
                        System.out.println("¡Felicidades usted ed de la Gen Z!");
                        
                    }else if(año >= 1980 && año <= 1994){
                        System.out.println("¡Felicidades usted es Millenial!");
                    }else if(año >= 1975 && año <= 1985){
                        System.out.println("¡Felicidades usted es de los Xennials!");
                    }else if(año >= 1960 && año <= 1979){
                        System.out.println("¡Felicidades usted es de la Generacion X");
                    }else if(año >= 1946 && año <= 1964){
                        System.out.println("Lo siento... Usted es un Boomer ._.");
                    }else{
                        System.out.println("Su edad no esta en el rango de las generaciones :( ");
                    }
                }//fin case 3
                break;
                case 4:{
                    seguir = false;
                }// fin case 4
                break;
                default:{
                    System.out.println("Numero invalido...");
                }//fin default
                break;
            }//fin switch
        }//fin while externo
    }//fin static void
    
}//fin class
